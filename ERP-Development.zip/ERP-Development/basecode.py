# def print_pattern(n):
#     for i in range(n):
#         for j in range (n):
#             print(n-min(i,j,n-i,n-1-j),end="")
#         print()



# n= 4
# print_pattern(n)
# print("\n")
# n=6
# print_pattern(n)


# a_string = "123"
# print(type(a_string)) 
  
# # Converting to long 
# a_long = int(a_string) 
# print(a_long) 
# print(type(a_long))

string="789"
print(type(string))
print(string)
convert=int(string)
print(type(convert))
print(convert)